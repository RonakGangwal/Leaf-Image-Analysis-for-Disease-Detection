
#### Leveraged Transfer Learning on VGG16 architecture to classify among 38 classes of plant-disease pairs
#### Considered output from activation layer of different blocks in the network as features, to check for layer which gives the best set of features for classification
#### Achieved an accuracy of 92.3%
